from hailo_platform.pyhailort.control_object import * # noqa F401
