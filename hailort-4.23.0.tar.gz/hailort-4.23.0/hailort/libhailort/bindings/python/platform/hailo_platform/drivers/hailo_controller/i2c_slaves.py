#!/usr/bin/env python
from hailo_platform.pyhailort.i2c_slaves import * # noqa F401