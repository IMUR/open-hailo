// SPDX-License-Identifier: GPL-2.0
/**
 * Copyright (c) 2019-2025 Hailo Technologies Ltd. All rights reserved.
 **/

#ifndef _FILE_OPERATIONS_H_
#define _FILE_OPERATIONS_H_

#include "board.h"

extern struct file_operations hailo_integrated_nnc_fops;

#endif //_FILE_OPERATIONS_H_